// button About
var buttonAboutEN = document.getElementById("buttonAboutEN");
function newpage(buttonAboutEN){
    window.location.href = "about.html"
}